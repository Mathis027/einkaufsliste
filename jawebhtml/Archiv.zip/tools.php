<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
header('Location: login.php');
exit;
} ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/style.css">
    <style>
        body {
            background-image: url('img/hkerpic.png');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
            width: 100vw;
            height: 100vh;
            position: absolute;
        }
         >
    </style>
</head>
<body>
<div class="content">
    <div class="buttons">
        <a href="modmenus.html">
            <button class="button1 glow-on-hover">gta modmenus</button>
        </a>
    </div>
    <div class="buttons">
        <a href="modmenus.html">
            <button class="button1 glow-on-hover">gta modmenus</button>
        </a>
    </div>
    <div class="buttons">
        <a href="modmenus.html">
            <button class="button1 glow-on-hover">gta modmenus</button>
        </a>
    </div>

</div>
<div class="content">
    <div class="buttons">
        <a href="modmenus.html">
            <button class="button1 glow-on-hover">gta modmenus</button>
        </a>
    </div>
    <div class="buttons">
        <a href="modmenus.html">
            <button class="button1 glow-on-hover">gta modmenus</button>
        </a>
    </div>
    <div class="buttons">
        <a href="modmenus.html">
            <button class="button1 glow-on-hover">gta modmenus</button>
        </a>
    </div>

</div>
<div class="content">
  <div class="buttons">
    <a href="modmenus.html">
      <button class="button1 glow-on-hover">gta modmenus</button>
    </a>  
  </div>
  <div class="buttons">
    <a href="modmenus.html">
      <button class="button1 glow-on-hover">gta modmenus</button>
    </a>  
  </div>
  <div class="buttons">
    <a href="modmenus.html">
      <button class="button1 glow-on-hover">gta modmenus</button>
    </a>  
  </div>

</div>
  


   

 
    
</body>
</html>